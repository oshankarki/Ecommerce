<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
// tag
Route::get('backend/tag/create',[\App\Http\Controllers\Backend\TagController::class,'create'])->name('backend.tag.create');
Route:: post('backend/tag',[\App\Http\Controllers\Backend\TagController::class,'store'])->name('backend.tag.store');
Route::get('backend/tag',[\App\Http\Controllers\Backend\TagController::class,'index'])->name('backend.tag.index');
Route:: get('backend/tag/{id}',[\App\Http\Controllers\backend\TagController::class,'show'])->name('backend.tag.show');
Route:: delete('backend/tag/{id}',[\App\Http\Controllers\backend\TagController::class,'destroy'])->name('backend.tag.destroy');
//route to edit data
Route:: get('backend/tag/{id}/edit',[\App\Http\Controllers\backend\TagController::class,'edit'])->name('backend.tag.edit');
//route to update data
Route:: put('backend/tag/{id}',[\App\Http\Controllers\backend\TagController::class,'update'])->name('backend.tag.update');

// Category
Route::get('backend/category/create',[\App\Http\Controllers\Backend\CategoryController::class,'create'])->name('backend.category.create');
Route:: post('backend/category',[\App\Http\Controllers\Backend\CategoryController::class,'store'])->name('backend.category.store');
Route::get('backend/category',[\App\Http\Controllers\Backend\CategoryController::class,'index'])->name('backend.category.index');
Route:: get('backend/category/{id}',[\App\Http\Controllers\backend\CategoryController::class,'show'])->name('backend.category.show');
Route:: delete('backend/category/{id}',[\App\Http\Controllers\backend\CategoryController::class,'destroy'])->name('backend.category.destroy');
//route to edit data
Route:: get('backend/category/{id}/edit',[\App\Http\Controllers\backend\CategoryController::class,'edit'])->name('backend.category.edit');
//route to update data
Route:: put('backend/categoryag/{id}',[\App\Http\Controllers\backend\CategoryController::class,'update'])->name('backend.category.update');

//brand
Route::get('backend/brand/create',[\App\Http\Controllers\Backend\BrandController::class,'create'])->name('backend.brand.create');
Route:: post('backend/brand',[\App\Http\Controllers\Backend\BrandController::class,'store'])->name('backend.brand.store');
Route::get('backend/brand',[\App\Http\Controllers\Backend\BrandController::class,'index'])->name('backend.brand.index');
Route:: get('backend/brand/{id}',[\App\Http\Controllers\backend\BrandController::class,'show'])->name('backend.brand.show');
Route:: delete('backend/brand/{id}',[\App\Http\Controllers\backend\BrandController::class,'destroy'])->name('backend.brand.destroy');
//route to edit data
Route:: get('backend/brand/{id}/edit',[\App\Http\Controllers\backend\BrandController::class,'edit'])->name('backend.brand.edit');
//route to update data
Route:: put('backend/brand/{id}',[\App\Http\Controllers\backend\BrandController::class,'update'])->name('backend.brand.update');


//product
Route::get('backend/product/create',[\App\Http\Controllers\Backend\ProductController::class,'create'])->name('backend.product.create');
Route:: post('backend/product',[\App\Http\Controllers\Backend\ProductController::class,'store'])->name('backend.product.store');
Route::get('backend/product',[\App\Http\Controllers\Backend\ProductController::class,'index'])->name('backend.product.index');
Route:: get('backend/product/{id}',[\App\Http\Controllers\backend\ProductController::class,'show'])->name('backend.product.show');
Route:: delete('backend/product/{id}',[\App\Http\Controllers\backend\ProductController::class,'destroy'])->name('backend.product.destroy');
//route to edit data
Route:: get('backend/product/{id}/edit',[\App\Http\Controllers\backend\ProductController::class,'edit'])->name('backend.product.edit');
//route to update data
Route:: put('backend/product/{id}',[\App\Http\Controllers\backend\ProductController::class,'update'])->name('backend.product.update');

//Sub Category
Route::get('backend/subcategory/create',[\App\Http\Controllers\Backend\SubcategoryController::class,'create'])->name('backend.subcategory.create');
Route:: post('backend/subcategory',[\App\Http\Controllers\Backend\SubcategoryController::class,'store'])->name('backend.subcategory.store');
Route::get('backend/subcategory',[\App\Http\Controllers\Backend\SubcategoryController::class,'index'])->name('backend.subcategory.index');
Route:: get('backend/subcategory/{id}',[\App\Http\Controllers\backend\SubcategoryController::class,'show'])->name('backend.subcategory.show');
Route:: delete('backend/subcategory/{id}',[\App\Http\Controllers\backend\SubcategoryController::class,'destroy'])->name('backend.subcategory.destroy');
//route to edit data
Route:: get('backend/subcategory/{id}/edit',[\App\Http\Controllers\backend\SubcategoryController::class,'edit'])->name('backend.subcategory.edit');
//route to update data
Route:: put('backend/subcategory/{id}',[\App\Http\Controllers\backend\SubcategoryController::class,'update'])->name('backend.subcategory.update');


