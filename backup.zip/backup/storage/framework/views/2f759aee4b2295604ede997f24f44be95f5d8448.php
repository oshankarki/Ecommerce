 <?php $__env->startSection('title','Category'); ?> <?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Cattegory Management</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Category</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">

    <!-- Default box -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Category</h3>

            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                        <i class="fas fa-times"></i>
                    </button>
            </div>
        </div>
        <form action="<?php echo e(route('backend.category.update',$category->id)); ?>" method="post">
        <input type="hidden" name="_method" value="PUT">
            <?php echo csrf_field(); ?>
            <div class="card-body">

                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" class="form-control" id="title" value="<?php echo e($category->title); ?>" placeholder="Enter Title">
                </div>
                
                <div class="form-group">
                    <label for="status">Slug</label>
                    <input type="text" name="slug" class="form-control" id="slug" value="<?php echo e($category->slug); ?>" placeholder="Status">
                </div>
                <div class="form-group">
                    <label for="rank">Rank</label>
                    <input type="number" name="rank" class="form-control" id="rank" value="<?php echo e($category->rank); ?>" placeholder="Rank">
                </div>
                <div class="form-group">
                    <label for="Image">Image</label></br>
                    <input type="file" name="image" class="" value="<?php echo e($category->image); ?>" id="image">
                </div>
                <div class="form-group">
                    <label for="meta_title">Meta Title</label>
                    <input type="text" name="meta_title" class="form-control" id="meta_title" value="<?php echo e($category->meta_title); ?>" placeholder="Meta Title">
                </div>
                <div class="form-group">
                    <label for="meta_keyword">Meta Keyword</label>
                    <input type="text" name="meta_keyword" class="form-control" id="meta_keyword" value="<?php echo e($category->meta_keyword); ?>" placeholder="Meta Keyword">
                </div>
                <div class="form-group">
                    <label for="meta_description">Meta Description</label><br>
                    <textarea name="meta_description" cols="40" rows="5"  value="<?php echo e($category->meta_description); ?>" placeholder="Meta Description"></textarea>
                </div>
                <div class="form-group">
                    <label for="status">Status</label><br>
                    <input type="radio" name="status" value="1"> Enable<br>
                    <input type="radio" name="status" value="2"> Disable<br>                  
                </div>
                
                <input type="hidden" value="<?php echo e(auth()->user()->id); ?>" name="updated_by">


            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>

        <!-- /.card-body -->
        <div class="card-footer">
            Footer
        </div>
        <!-- /.card-footer-->
    </div>
    <!-- /.card -->

</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/oshankarki/EcommerceApp/resources/views/backend/category/edit.blade.php ENDPATH**/ ?>